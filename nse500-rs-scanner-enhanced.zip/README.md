# NSE 500 RS Scanner

A Streamlit dashboard for relative-strength ratings, Minervini Trend Template checks, VCP setups, volume breakouts, Stage 1 bases and industry strength across the Nifty 500.

## Features

- Relative-strength ratings from weighted 3, 6, 9 and 12 month returns.
- Filters for RS rating, industry and company or symbol search.
- Dedicated views for top picks, Trend Template passes, VCP setups, breakouts, Stage 1 bases, RS blue dots, industries and all stocks.
- CSV downloads for scanner results.
- **Stock detail:** review recent prices with 50, 150 and 200 day moving averages, compare indexed performance with the benchmark, and inspect current scanner signals.
- Cached market data and a manual refresh control.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Streamlit Community Cloud

1. Push the project folder to a GitHub repository.
2. In Streamlit Community Cloud, create an app from that repository and select `app.py` as the main file.
3. Deploy. The app downloads NSE 500 constituents and daily prices when it runs; it does not require API secrets.

If the NSE constituent download is unavailable, upload `ind_nifty500list.csv` in the app. Yahoo Finance data availability and rate limits can affect scan results and refresh times.

## Notes

RS ratings are percentile ranks within this app's NSE 500 universe. Pattern and stage labels are rule based and are intended as screening aids; confirm signals independently. This project is for informational and educational use and is not investment advice.
